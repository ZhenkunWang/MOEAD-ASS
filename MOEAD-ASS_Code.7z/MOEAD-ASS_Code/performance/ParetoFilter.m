function ParetoF = ParetoFilter( F)

% [ParetoF,ParetoX] = ParetoFilter( F, X ) filter the Pareto solutions from
% F and X
%
%     Parameters:
%     X  - data set (X)
%     F  - data set (F)
%     Size - data size to keep
%     Returns:
%     ParetoX   - nondominated solutions (X) 
%     ParetoF   - nondominated solutions (F)
%
%     Aimin Zhou
%     Department of Computer Science
%     University of Essex
%     Colchester, U.K, CO4 3SQ
%     amzhou@gmail.com
%
% History:
%     14/10/2006 create


DF  = size(F,1);
NF  = size(F,2);

exist   = ones(NF,1);     % exist or not
for i=1:1:NF
    for j=i+1:1:NF
        % Fi dominate Fj
        if(sum(F(:,i) <= F(:,j)) == DF && sum(F(:,i) == F(:,j)) < DF)
            exist(j) = 0;
        % Fj dominate Fi
        elseif(sum(F(:,i) >= F(:,j)) == DF && sum(F(:,i) == F(:,j)) < DF)
            exist(i) = 0;
        end        
    end
end

NN = sum(exist);
ParetoF = ones(DF,NN);
% ParetoX = ones(size(X,1),NN);
k = 1;
for i=1:1:NF
    if(exist(i)>0)
%         ParetoX(:,k) = X(:,i);
        ParetoF(:,k) = F(:,i);
        k = k + 1;
    end
end