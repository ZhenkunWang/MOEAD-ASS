% testset={'tec09_f2','tec09_f2','tec09_f3','tec09_f4','tec09_f5','tec09_f7','tec09_f8','tec09_f9','tec09_f6'};
% result=zeros(length(testset),30);
% testset={'MOP5','MOP2','MOP3','MOP5','MOP4'};
testset={'MOP6','MOP7','tec09_f6'};
for i=1:length(testset)
testname=testset{i};
 f       = sprintf('E:/IGD/%s/%s-IGD',testname,testname);
% f='E:/result/tec09_f2'
d=load(f);
igd=d.result;
mean(igd)
min(igd)
std2(igd)
% mean(result)
clear f ind PF;
disp('----------------------------------------');

end