function ParetoFilter_TEST( )

%     Aimin Zhou
%     Department of Computer Science
%     University of Essex
%     Colchester, U.K, CO4 3SQ
%     amzhou@gmail.com
%
% History:
%     15/10/2006 create

F = rand(3,100);
% X = rand(2,100);

ParetoF = ParetoFilter( F );

hold off;
 plot3(F(1,:),F(2,:),F(3,:),'b.', 'MarkerSize',4); hold on;
 plot3(ParetoF(1,:),ParetoF(2,:),ParetoF(3,:),'rs', 'MarkerSize',4);
