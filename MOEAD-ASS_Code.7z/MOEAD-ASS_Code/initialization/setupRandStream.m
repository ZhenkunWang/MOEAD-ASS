% Set up the global random number state to the specific stream
% and substream using combined recursive generator.
% Example:
% % % rng('default'); rng('shuffle');
% % % streamOffset=randi(10000);
% % % nrun=20;
% % % nloop=2;
% % % zz=zeros(nloop,nrun);
% % % for wloop=1:nloop
% % %     delete(gcp('nocreate'));parpool(20);
% % %     parfor wrun=1:nrun
% % %         %     rng('shuffle');%minor effects
% % %         setupRandStream(wloop+streamOffset,wrun);%significant effects
% % %         zz(wloop,wrun)=rand;
% % %     end
% % % end
% % % nrand=size(unique(zz));
function setupRandStream(stream, substream)
s = RandStream.create('mrg32k3a', 'NumStreams', stream, ...
    'StreamIndices', stream);
s.Substream = substream;
RandStream.setGlobalStream(s);
end