function [params,mop]=loadparams(testname,varargin)
%LOADPARAMS Load the parameter settings from external file.
%   The detailed explanation goes here, MOEA/D-ASMS uses two optimizers, one
%   is the 'minimize' optimizer which is responsible for the training of GP/MOGP 
%   models, the other one is GA which aims to find the most potential 'Ke' 
%   solutions according to the built surrogate models.
  params = get_structure('parameter');
  % General Setting for MOEA/D-ASMS
  params.Dmethod = 'rtch'; %decomposition method both in the subproblem modeling and in the decomposition in MOEA/D-DE optimizer.
  params.Ke = 5;%the maximum number of points selected for evalutation at each iteration
  params.Mindiffer = 1e-3;% the minimum Euclidean distance for identifying two different solutions
  params.N_task = 5;
  params.TrainSize = 100;
  % set for the default for a specific problem here.
  switch lower(testname)
	case {'kno1','pol'}
      xobj=2; 
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;
    case {'zdt1','zdt2','zdt3','zdt4','zdt6'}
      xobj=8;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=99;
      params.MOEAD_NeiSize=20;
    case {'wfg1','wfg2','wfg3','wfg4','wfg5','wfg6','wfg7','wfg8','wfg9'}
      xobj=8;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=99;
      params.MOEAD_NeiSize=20;     
    case {'dtlz1','dtlz2','dtlz3','dtlz4','dtlz5','dtlz6','dtlz7','convexdtlz2'}
      xobj=8;
      params.evaluation=500;    
      params.initsize=11*xobj-1;
      params.MOEAD_H=23;
      params.MOEAD_NeiSize=20;
    case {'mdtlz1','mdtlz2','mdtlz3','mdtlz4'}
      xobj=6;
      params.evaluation=300;        
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;
      params.MOEAD_NeiSize=20;
    case {'wb','tsd'}
      xobj=4;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;     
     case {'glt1','glt2','glt3','glt4'}
      xobj=8;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;
    case {'glt5','glt6'}
      xobj=6;
      params.evaluation=300;
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;
      params.MOEAD_NeiSize=20;
    case {'jy1','jy2','jy3','jy4','jym4'}
      xobj=8;
      params.evaluation=300;         
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;
    case {'jy5','jy6'}
      xobj=6;
      params.evaluation=300;         
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;
      params.MOEAD_NeiSize=20;
    case {'lgz1','lgz2','lgz3','lgz4','lgz5'}
      xobj=8;
      params.evaluation=200;         
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;
    case {'lgz6','lgz7'}
      xobj=6;
      params.evaluation=300;         
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;
      params.MOEAD_NeiSize=20;   
    case {'lz1','lz2','lz3','lz4','lz5','lz7','lz8','lz9'}
      xobj=8;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;
    case {'lz6'}
      xobj=6;
      params.evaluation=300;
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;
      params.MOEAD_NeiSize=20;
    case {'uf1','uf2','uf3','uf4','uf5','uf6','uf7'}
      xobj=8;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;
      params.MOEAD_NeiSize=20;
    case {'uf8','uf9','uf10'}
      xobj=6;
      params.evaluation=300;
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;      
      params.MOEAD_NeiSize=20;
    case {'wzlij1','wzlij2','wzlij3','wzlij4'...
               'wzlij5','wzlij6','wzlij7'}
      xobj=8;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;      
      params.MOEAD_NeiSize=20;
    case {'wzlij8','wzlij9'}
      xobj=6;
      params.evaluation=300;
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;      
      params.MOEAD_NeiSize=20;
    case {'wosgz1','wosgz2','wosgz3','wosgz4'...
               'wosgz5','wosgz6','wosgz7','wosgz8'}
      xobj=8;
      params.evaluation=200;
      params.initsize=11*xobj-1;
      params.MOEAD_H=299;      
      params.MOEAD_NeiSize=20;
    case {'wosgz9','wosgz10','wosgz11','wosgz12'...
               'wosgz13','wosgz14','wosgz15','wosgz16'}
      xobj=6;
      params.evaluation=300;
      params.initsize=11*xobj-1;
      params.MOEAD_H=33;      
      params.MOEAD_NeiSize=20;
    otherwise
      warning('Unsupported mop name');
  end
  % handle the parameters passed in from the function directly!
    mop=testmop(testname,xobj);
    params.N_dim=xobj;
    params.N_obj=mop.od;
%% -------------------------Model Settings---------------------------------
    params.ModelMethod = 'CoMOGP';
    % 'TrGP': transferred GP, obtain the other GPS from N_obj built GPs
    % 'InGP': independent GP, build GP for each subproblem/task
    % 'MTGP': multi-task GP
    % 'SLFM': semi-parametric latent factor model (also known as linear model of coregionalization)
    % 'CoMOGP': collaborative multi-output Gaussian process
    % 'CONV': process convolution
%==============================================================================
end

