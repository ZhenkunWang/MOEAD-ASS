function mop=testmop(testname,pdim)
%Get test multi-objective problems from a given name. 
%   The method get testing or benchmark problems for Multi-Objective
%   Optimization. The test problem will be encapsulated in a structure,
%   which can be obtained by function get_structure('testmop'). 
%   User get the corresponding test problem, which is an instance of class
%   mop, by passing the problem name and optional dimension parameters.
mop=struct('name',[],'od',[],'pd',[],'domain',[],'func',[]);
    switch lower(testname)
        case 'wb'
            mop=wb(mop);
        case 'tsd'
            mop=tsd(mop);
        case 'kno1'
            mop=kno1(mop);
        case 'pol'
            mop=pol(mop);
        case 'convexdtlz2'
            odim=3;
            mop=convexdtlz2(mop,pdim,odim);
        case {'zdt1','zdt2','zdt3','zdt4','zdt6'}
            mop=zdt(mop,testname,pdim);
        case {'dtlz1','dtlz2','dtlz3','dtlz4','dtlz5','dtlz6','dtlz7'}
            odim=3;
            mop=dtlz(mop,testname,pdim,odim);            
        case {'mdtlz1','mdtlz2','mdtlz3','mdtlz4'}
            odim=3;
            mop=mDTLZ(mop,testname,pdim,odim);  
        case {'wfg1','wfg2','wfg3','wfg4','wfg5','wfg6','wfg7','wfg8','wfg9'}
            odim=2; k=odim-1;
            mop=wfg(mop,testname,pdim,odim,k);  
        case {'lz1','lz2','lz3','lz4','lz5','lz6','lz7','lz8','lz9'}
            mop=lz(mop,testname,pdim);
        case {'zzj1','zzj2','zzj3','zzj4','zzj5','zzj6','zzj7','zzj8','zzj9','zzj10'}
            mop=zzj(mop,testname,pdim);
        case {'glt1','glt2','glt3','glt4','glt5','glt6'}
            mop=glt(mop,testname,pdim);
        case {'jy1','jy2','jy3','jy4','jy5','jy6','jym4'}
            mop=jy(mop,testname,pdim);
        case {'lgz1','lgz2','lgz3','lgz4','lgz5','lgz6','lgz7'}
            mop=lgz(mop,testname,pdim);            
        case {'wzlij1','wzlij2','wzlij3','wzlij4','wzlij5','wzlij6','wzlij7','wzlij8','wzlij9'}
            mop=wzlij(mop,testname,pdim);
        case {'wosgz1','wosgz2','wosgz3','wosgz4','wosgz5','wosgz6','wosgz7','wosgz8','wosgz9','wosgz10','wosgz11','wosgz12','wosgz13','wosgz14','wosgz15','wosgz16'}
            mop=wosgz(mop,testname,pdim);
        case {'uf1', 'uf2','uf3','uf4','uf5','uf6','uf7'}
            mop=cecproblems(mop,testname, pdim);
            mop.od=2;
        case {'uf8','uf9','uf10'}
            mop=cecproblems(mop,testname, pdim);
            mop.od=3;
        case {'r2_dtlz2_m5', 'r3_dtlz3_m5', 'wfg1_m5'}
            mop=cecproblems2(mop,testname, pdim); 
        otherwise 
            error('Undefined test problem name'); 
    end    
end
%%  KNO1 function generator
function p=kno1(p)
 p.name='KNO1';
 p.od = 2;      % dimension of objectives
 p.pd = 2;      % dimension of x
 p.domain= [0 3;0 3];   % search domain
 p.func = @evaluate;
 function y = evaluate(x) %KNO1 evaluation function.
    y=zeros(2,1);
    c = x(1)+x(2);
	f = 9-(3*sin(2.5*c^2) + 3*sin(4*c) + 5 *sin(2*c+2));
	g = (pi/2.0)*(x(1)-x(2)+3.0)/6.0;
	y(1)= 20-(f*cos(g));
	y(2)= 20-(f*sin(g)); 
 end
end
%%  POL function generator
function p=pol(p)
 p.name='POL';
 p.od = 2;      % dimension of objectives
 p.pd = 2;      % dimension of x
 p.domain= [-pi pi;-pi pi];   % search domain
 p.func = @evaluate;
 function y = evaluate(x) %KNO1 evaluation function.
	y=zeros(2,1);
	A1=0.5*sin(1)-2*cos(1)+sin(2)-1.5*cos(2);
	A2=1.5*sin(1)-cos(1)+2*sin(2)-0.5*cos(2);
	B1=0.5*sin(x(1))-2*cos(x(1))+sin(x(2))-1.5*cos(x(2));
	B2=1.5*sin(x(1))-cos(x(1))+2*sin(x(2))-0.5*cos(x(2));        
	y(1)= 1+(A1-B1)^2+(A2-B2)^2;
	y(2)= (x(1)+3)^2+(x(2)+1)^2; 
 end
end
%% TSD function generator
function p=tsd(p)
 p.name='TSD';
 p.od = 2;      % dimension of objectives
 p.pd = 4;      % dimension of x
 p.domain = [150 200;25 72;1 4.0;1 4.0];   % search domain
 p.func = @evaluate;
 function y = evaluate(x) %KNO1 evaluation function.
    y=zeros(2,1);
x_3 = round(x(3));
x_4 = round(x(4));
d_a_set = [80 85 90 95];
d_b_set = [75 80 85 90];
d_a = zeros(size(x,2),1);
d_b = zeros(size(x,2),1);
for i = 1:size(x,2)
    d_a(i) = d_a_set(x_3(i));
    d_b(i) = d_b_set(x_4(i));
end
% Var = l,d_o,d_a,d_b
    d_om = 25;
    d_a1 = 80;
    d_a2 = 95;
    d_b1 = 75;
    d_b2 = 90;
    p_1 = 1.25;
    p_2 = 1.05;
    l_k = 150;
    l_g = 200;
    a = 80;
    E = 210000;
    F = 10000;
    del_a = 0.0054;
    del_b = -0.0054;
    del = 0.01;
    del_ra = -0.001;
    del_rb = -0.001;
    I_a = 0.049*(d_a.^4 - x(2).^4);
    I_b = 0.049*(d_b.^4 - x(2).^4);
    c_a = 35400*abs(del_ra)^(1/9)*d_a.^(10/9);
    c_b = 35400*abs(del_rb)^(1/9)*d_b.^(10/9);   
    g(:,1) = p_1*x(2) - d_b;
	g(:,2) = p_2*d_b - d_a;
	g(:,3) = abs(del_a + (del_a - del_b)*a./x(1)) - del;
    cv = sum(max(g,0),2);
    y(1)  = pi/4*(a*(d_a.^2 - x(2).^2) + x(1).*(d_b.^2 - x(2).^2))+1e6*cv;
	y(2) = F*a^3./(3*E.*I_a).*(1 + (x(1).*I_a)./(a*I_b)) + (F./c_a).*((1 + a./x(1)).^2 + (c_a*a^2)./(c_b.*x(1).^2))+1e6*cv;
 end
end
%%  WB function generator
function p=wb(p)
 p.name='WB';
 p.od = 2;      % dimension of objectives
 p.pd = 4;      % dimension of x
 p.domain = [0.125 5.0;0.1 10.0;0.125 5.0;0.1 10.0];   % search domain
 p.func = @evaluate;
 function y = evaluate(x) %KNO1 evaluation function.
    y=zeros(2,1);
    h = x(1);
    l = x(2);
    t = x(3);
    b = x(4);
    delta = 2.1952./(b.*t.^3);
    sigma = 504000./(b.*t.^2);
    P_c = 64746.022.*(1 - 0.0282346.*t).*t.*b.^3;
    tau_1 = 6000./(sqrt(2).*h.*l);
    tau_2 = (6000.*(14 + 0.5.*l).*(sqrt(0.25.*(l.^2 + (h + t).^2))))./(2.*(0.707.*h.*l.*(l.^2./12 + 0.25.*(h + t).^2)));
    tau = sqrt(tau_1.^2 + tau_2.^2 + (l.*tau_1.*tau_2)./(sqrt(0.25.*(l.^2 + (h + t).^2))));
g(:,1) = tau - 13600;
g(:,2) = sigma - 30000;
g(:,3) = h - b;
g(:,4) = 6000 - P_c;
cv = sum(max(g,0),2); 
y(1) = 1.10471.*h.^2.*l + 0.04811.*t.*b.*(14 + l)+1e6*cv;
y(2) = delta+1e6*cv;
 end
end
%%
function p =convexdtlz2(p,pdim,odim)
 p.name     = 'ConvexDTLZ2';
 p.pd       = pdim;% default pd=30
 p.od       = odim;
 p.domain   = [zeros(1,pdim); ones(1,pdim)];
 p.func     = @evaluate;
function y = evaluate(x)
	n   = pdim;
    g=sum((x(3:n)-0.5).^2);
    y   = zeros(1,3);
    y(1)= ((1+g)*cos(0.5*pi*x(1))*cos(0.5*pi*x(2)))^4;
    y(2)= ((1+g)*cos(0.5*pi*x(1))*sin(0.5*pi*x(2)))^4;
    y(3)= ((1+g)*sin(0.5*pi*x(1)))^4;
end
end
%cec09 UF1 - UF10
function p=cecproblems(p, testname,dim)
 p.name=upper(testname);
 p.pd=dim;
 p.domain=xboundary(upper(testname),dim);
 p.func=cec09(upper(testname));
end

%cec09 UF11 - UF13
function p=cecproblems2(p, testname,dim)
 p.name=upper(testname);
 p.pd=dim;
 p.od=2;
 p.domain=xboundary(upper(testname),dim);
 p.func=cec09m(upper(testname));
end



