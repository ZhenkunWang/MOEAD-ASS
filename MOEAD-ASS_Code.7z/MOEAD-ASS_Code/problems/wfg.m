function mop=wfg(mop,testname,pdim,odim,k)
%%run for the test problems dtlz serious.
switch lower(testname)
    case 'wfg1'
        mop=wfg1(mop,pdim,odim,k);
    case 'wfg2'
        mop=wfg2(mop,pdim,odim,k);        
    case 'wfg3'
        mop=wfg3(mop,pdim,odim,k);        
    case 'wfg4'
        mop=wfg4(mop,pdim,odim,k);        
    case 'wfg5'
        mop=wfg5(mop,pdim,odim,k);        
    case 'wfg6'
        mop=wfg6(mop,pdim,odim,k);        
    case 'wfg7'
        mop=wfg7(mop,pdim,odim,k);    
    case 'wfg8'
        mop=wfg8(mop,pdim,odim,k);        
    case 'wfg9'
        mop=wfg9(mop,pdim,odim,k); 
    otherwise
        error('Undefined test problem name');
end
end
%%
%%%%%%%%%%FUNCTIONS%%%%%%
function p=wfg1(p,pdim,odim,k)
   p.name='WFG1';
   p.od=odim;
   p.pd=pdim;
   bu=(2:2:2*pdim)';
   p.domain=[zeros(pdim,1) bu];
   p.func=@evaluate;
   function y=evaluate(z)
     x=z./bu;
     t1(1:k,:)=x(1:k,:);
     t1(k+1:pdim,:)=abs(x(k+1:pdim,:)-0.35)./abs(floor(0.35-x(k+1:pdim,:))+0.35);
     t2(1:k,:)=t1(1:k,:);
     A=0.8;
     B=0.75;
     C=0.85;  
    for i=k+1:pdim
     t2(i,:)=A+min(0,floor(t1(i,:)-B))*(A*(B-t1(i,:))/B)-min(0,floor(C-t1(i,:)))*((1-A)*(t1(i,:)-C)/(1-C));
    end
     a=0.02;
    for i=1:pdim
      t3(i,:)=t2(i,:).^a;
    end
   for i=1:odim-1
    W=2*(i-1)*k/(odim-1)+1:2:2*i*k/(odim-1);
    y=t3((i-1)*k/(odim-1)+1:i*k/(odim-1),:);
%     W=repmat(w,1,1);
    t4(i,:)=sum(y.*W')/sum(W);
   end
   W=2*(k+1):2:2*pdim;
   y=t3(k+1:end,:);
%    W=repmat(w,1,1);
   t4(odim,:)=sum(y.*W')/sum(W);
   x=[];
%   for i=1:1
%     x(:,i)=max(t4(:,odim),ones(1,1)).*(t4(:,i)-0.5)+0.5;
%   end
  for i=1:odim-1
    x(i,:)=max(t4(odim,:),1).*(t4(i,:)-0.5)+0.5;
  end
  x(odim,:)=t4(odim,:);
  A=5;
  a=1;

    h(1,:)=prod(1-cos(0.5*pi*x(1:odim-1)));
for i=2:odim-1
    h(i,:)=prod(1-cos(0.5*pi*x(1:odim-i))).*(1-sin(0.5*pi*x(odim-i+1)));
end
h(odim,:)=(1-x(1,:)-cos(2*A*pi*x(1)+0.5*pi)/(2*A*pi)).^a;
s=2:2:2*odim;
% s=ones(1,1)*s;
y=x(odim,:)*1+s'.*h;
   end
end
%%%%%%%
function p=wfg2(p,pdim,odim,k)
   p.name='WFG2';
   p.od=odim;
   p.pd=pdim;
   bu=(2:2:2*pdim)';
   p.domain=[zeros(pdim,1) bu];
   p.func=@evaluate;
   function y=evaluate(z)
     n=size(z,2);
     x=(z./bu)';
t1(:,1:k)=x(:,1:k);
t1(:,k+1:pdim)=abs(x(:,k+1:pdim)-0.35)./abs(floor(0.35-x(:,k+1:pdim))+0.35);
t2(:,1:k)=t1(:,1:k);
for i=k+1:k+(pdim-k)/2
    y=t1(:,k+(i-k)*2-1:k+(i-k)*2);
    t2(:,i)=(y(:,1)+y(:,2)+2*abs(y(:,1)-y(:,2)))/3;
end
for i=1:odim-1
    y=t2(:,(i-1)*k/(odim-1)+1:i*k/(odim-1));
    t3(:,i)=sum(y,2)/size(y,2);
end
y=t2(:,k+1:end);
t3(:,odim)=sum(y,2)/size(y,2);
x=[];
for i=1:1
    x(:,i)=max(t3(:,odim),ones(n,1)).*(t3(:,i)-0.5)+0.5;
end
for i=2:odim-1
    x(:,i)=max(t3(:,odim),ones(n,1)).*(t3(:,i)-0.5)+0.5;
end
x(:,odim)=t3(:,odim);
A=5;
a=1;
b=1;
h(:,1)=prod(1-cos(0.5*pi*x(:,1:odim-1)),2);
for i=2:odim-1
    h(:,i)=prod(1-cos(0.5*pi*x(:,1:odim-i)),2).*(1-sin(0.5*pi*x(:,odim-i+1)));
end
h(:,odim)=1-(x(:,1).^a).*(cos(A*pi*(x(:,1).^b)).^2);
s=2:2:2*odim;
s=ones(n,1)*s;
y=(x(:,odim)*ones(1,odim)+s.*h)';
   end
end
%%%%%%%
function p=wfg3(p,pdim,odim,k)
   p.name='WFG3';
   p.od=odim;
   p.pd=pdim;
   bu=(2:2:2*pdim)';
   p.domain=[zeros(pdim,1) bu];
   p.func=@evaluate;
   function y=evaluate(z)
     n=size(z,2);
     x=(z./bu)';
t1(:,1:k)=x(:,1:k);
t1(:,k+1:pdim)=abs(x(:,k+1:pdim)-0.35)./abs(floor(0.35-x(:,k+1:pdim))+0.35);
t2(:,1:k)=t1(:,1:k);
for i=k+1:k+(pdim-k)/2
    y=t1(:,k+(i-k)*2-1:k+(i-k)*2);
    t2(:,i)=(y(:,1)+y(:,2)+2*abs(y(:,1)-y(:,2)))/3;
end
for i=1:odim-1
    y=t2(:,(i-1)*k/(odim-1)+1:i*k/(odim-1));
    t3(:,i)=sum(y,2)/size(y,2);
end
y=t2(:,k+1:end);
t3(:,odim)=sum(y,2)/size(y,2);
% t=max(t3(:,m),ones(n,1));
x=[];
for i=1:1
    x(:,i)=max(t3(:,odim),ones(n,1)).*(t3(:,i)-0.5)+0.5;
end
for i=2:odim-1
    x(:,i)=max(t3(:,odim),zeros(n,1)).*(t3(:,i)-0.5)+0.5;
end
x(:,odim)=t3(:,odim);

h(:,1)=prod(x(:,1:odim-1),2);
for i=2:odim-1
    h(:,i)=prod(x(:,1:odim-i),2).*(1-x(:,odim-i+1));
end
h(:,odim)=1-x(:,1);
s=2:2:2*odim;
s=ones(n,1)*s;
y=(x(:,odim)*ones(1,odim)+s.*h)';
   end
end
%%%%%%%
function p=wfg4(p,pdim,odim,k)
   p.name='WFG4';
   p.od=odim;
   p.pd=pdim;
   bu=(2:2:2*pdim)';
   p.domain=[zeros(pdim,1) bu];
   p.func=@evaluate;
function y=evaluate(z)
     n=size(z,2);
     x=(z./bu)';
A=30;
B=10;
C=0.35;

for i=1:pdim
    t1(:,i)=(1+cos((4*A+2)*pi*(0.5-(abs(x(:,i)-C))./(2*(floor(C-x(:,i))+C))))+4*B*(((abs(x(:,i)-C))./(2*(floor(C-x(:,i))+C))).^2))/(B+2);
end
for i=1:odim-1
    y=t1(:,(i-1)*k/(odim-1)+1:i*k/(odim-1));
    t2(:,i)=sum(y,2)/size(y,2);
end
y=t1(:,k+1:end);
t2(:,odim)=sum(y,2)/size(y,2);
x=[];
for i=1:1
    x(:,i)=max(t2(:,odim),ones(n,1)).*(t2(:,i)-0.5)+0.5;
end
for i=2:odim-1
    x(:,i)=max(t2(:,odim),ones(n,1)).*(t2(:,i)-0.5)+0.5;
end
x(:,odim)=t2(:,odim);

h(:,1)=prod(sin(0.5*pi*x(:,1:odim-1)),2);
for i=2:odim-1
    h(:,i)=prod(sin(0.5*pi*x(:,1:odim-i)),2).*(cos(0.5*pi*x(:,odim-i+1)));
end
h(:,odim)=cos(0.5*pi*x(:,1));
s=2:2:2*odim;
s=ones(n,1)*s;
y=(x(:,odim)*ones(1,odim)+s.*h)';
   end
end
%%%%%%%
function p=wfg5(p,pdim,odim,k)
   p.name='WFG5';
   p.od=odim;
   p.pd=pdim;
   bu=(2:2:2*pdim)';
   p.domain=[zeros(pdim,1) bu];
   p.func=@evaluate;
   function y=evaluate(z)
     n=size(z,2);
     x=(z./bu)';
A=0.35;
B=0.001;
C=0.05;

for i=1:pdim
    t1(:,i)=1+(abs(x(:,i)-A)-B).*(floor(x(:,i)-A+B)*(1-C+(A-B)/B)/(A-B)+floor(A+B-x(:,i))*(1-C+(1-A-B)/B)/(1-A-B)+1/B);
end
for i=1:odim-1
    y=t1(:,(i-1)*k/(odim-1)+1:i*k/(odim-1));
    t2(:,i)=sum(y,2)/size(y,2);
end
y=t1(:,k+1:end);
t2(:,odim)=sum(y,2)/size(y,2);
x=[];
for i=1:1
    x(:,i)=max(t2(:,odim),ones(n,1)).*(t2(:,i)-0.5)+0.5;
end
for i=2:odim-1
    x(:,i)=max(t2(:,odim),ones(n,1)).*(t2(:,i)-0.5)+0.5;
end
x(:,odim)=t2(:,odim);

h(:,1)=prod(sin(0.5*pi*x(:,1:odim-1)),2);
for i=2:odim-1
    h(:,i)=prod(sin(0.5*pi*x(:,1:odim-i)),2).*(cos(0.5*pi*x(:,odim-i+1)));
end
h(:,odim)=cos(0.5*pi*x(:,1));
s=2:2:2*odim;
s=ones(n,1)*s;
y=(x(:,odim)*ones(1,odim)+s.*h)';
   end
end
%%%%%%%
function p=wfg6(p,pdim,odim,k)
   p.name='WFG6';
   p.od=odim;
   p.pd=pdim;
   bu=(2:2:2*pdim)';
   p.domain=[zeros(pdim,1) bu];
   p.func=@evaluate;
   function y=evaluate(z)
     n=size(z,2);
     x=(z./bu)';
t1(:,1:k)=x(:,1:k);
t1(:,k+1:pdim)=abs(x(:,k+1:pdim)-0.35)./abs(floor(0.35-x(:,k+1:pdim))+0.35);

for i=1:odim-1
    y=t1(:,(i-1)*k/(odim-1)+1:i*k/(odim-1));
    A=k/(odim-1);
    for j=1:size(y,2)
        s(:,j)=y(:,j);
        for p=0:A-2
            s(:,j)=s(:,j)+abs(y(:,j)-y(:,1+mod(j+p,size(y,2))));
        end
    end
    t2(:,i)=sum(s,2)/(size(y,2)/A*ceil(A/2)*(1+2*A-2*ceil(A/2)));
end
y=t1(:,k+1:end);
A=pdim-k;
for j=1:size(y,2)
    s(:,j)=y(:,j);
    for p=0:A-2
        s(:,j)=s(:,j)+abs(y(:,j)-y(:,1+mod(j+p,size(y,2))));
    end
end
t2(:,odim)=sum(s,2)/(size(y,2)/A*ceil(A/2)*(1+2*A-2*ceil(A/2)));
x=[];
for i=1:1
    x(:,i)=max(t2(:,odim),ones(n,1)).*(t2(:,i)-0.5)+0.5;
end
for i=2:odim-1
    x(:,i)=max(t2(:,odim),ones(n,1)).*(t2(:,i)-0.5)+0.5;
end
x(:,odim)=t2(:,odim);

h(:,1)=prod(sin(0.5*pi*x(:,1:odim-1)),2);
for i=2:odim-1
    h(:,i)=prod(sin(0.5*pi*x(:,1:odim-i)),2).*(cos(0.5*pi*x(:,odim-i+1)));
end
h(:,odim)=cos(0.5*pi*x(:,1));
s=2:2:2*odim;
s=ones(n,1)*s;
y=(x(:,odim)*ones(1,odim)+s.*h)';
   end
end
%%%%%%%
function p=wfg7(p,pdim,odim,k)
   p.name='WFG7';
   p.od=odim;
   p.pd=pdim;
   bu=(2:2:2*pdim)';
   p.domain=[zeros(pdim,1) bu];
   p.func=@evaluate;
   function y=evaluate(z)
     n=size(z,2);
     x=(z./bu)';
A=0.98/49.98;
B=0.02;
C=50;
for i=1:k
    y=x(:,i+1:pdim);
    Y=sum(y,2)/size(y,2);
    for j=1:size(Y,1)
        if Y(j)<0.5
            u(j,1)=Y(j)*((C-B)*A)*2+B;
        else
            u(j,1)=(Y(j)-0.5)*(C-((C-B)*A+B))*2+(C-B)*A+B;
        end
    end
    v=A-(1-2*u).*abs(floor(0.5-u)+A);
    t1(:,i)=x(:,i).^(B+(C-B)*v);
end
t1(:,k+1:pdim)=x(:,k+1:pdim);

t2(:,1:k)=t1(:,1:k);
t2(:,k+1:pdim)=abs(t1(:,k+1:pdim)-0.35)./abs(floor(0.35-t1(:,k+1:pdim))+0.35);
for i=1:odim-1
    y=t2(:,(i-1)*k/(odim-1)+1:i*k/(odim-1));
    t3(:,i)=sum(y,2)/size(y,2);
end
y=t2(:,k+1:end);
t3(:,odim)=sum(y,2)/size(y,2);
x=[];
for i=1:1
    x(:,i)=max(t3(:,odim),ones(n,1)).*(t3(:,i)-0.5)+0.5;
end
for i=2:odim-1
    x(:,i)=max(t3(:,odim),ones(n,1)).*(t3(:,i)-0.5)+0.5;
end
x(:,odim)=t3(:,odim);

h(:,1)=prod(sin(0.5*pi*x(:,1:odim-1)),2);
for i=2:odim-1
    h(:,i)=prod(sin(0.5*pi*x(:,1:odim-i)),2).*(cos(0.5*pi*x(:,odim-i+1)));
end
h(:,odim)=cos(0.5*pi*x(:,1));
s=2:2:2*odim;
s=ones(n,1)*s;
y=(x(:,odim)*ones(1,odim)+s.*h)';
   end
end
%%%%%%%
function p=wfg8(p,pdim,odim,k)
   p.name='WFG8';
   p.od=odim;
   p.pd=pdim;
   bu=(2:2:2*pdim)';
   p.domain=[zeros(pdim,1) bu];
   p.func=@evaluate;
   function y=evaluate(z)
     n=size(z,2);
     x=(z./bu)';
A=0.98/49.98;
B=0.02;
C=50;
t1(:,1:k)=x(:,1:k);
for i=k+1:pdim
    y=x(:,1:i-1);
    Y=sum(y,2)/size(y,2);
    for j=1:size(Y,1)
        if Y(j)<0.5
            u(j,1)=Y(j)*((C-B)*A)*2+B;
        else
            u(j,1)=(Y(j)-0.5)*(C-((C-B)*A+B))*2+(C-B)*A+B;
        end
    end
    v=A-(1-2*u).*abs(floor(0.5-u)+A);
    t1(:,i)=x(:,i).^(B+(C-B)*v);
end

t2(:,1:k)=t1(:,1:k);
t2(:,k+1:pdim)=abs(t1(:,k+1:pdim)-0.35)./abs(floor(0.35-t1(:,k+1:pdim))+0.35);
for i=1:odim-1
    y=t2(:,(i-1)*k/(odim-1)+1:i*k/(odim-1));
    t3(:,i)=sum(y,2)/size(y,2);
end
y=t2(:,k+1:end);
t3(:,odim)=sum(y,2)/size(y,2);
x=[];
for i=1:1
    x(:,i)=max(t3(:,odim),ones(n,1)).*(t3(:,i)-0.5)+0.5;
end
for i=2:odim-1
    x(:,i)=max(t3(:,odim),ones(n,1)).*(t3(:,i)-0.5)+0.5;
end
x(:,odim)=t3(:,odim);

h(:,1)=prod(sin(0.5*pi*x(:,1:odim-1)),2);
for i=2:odim-1
    h(:,i)=prod(sin(0.5*pi*x(:,1:odim-i)),2).*(cos(0.5*pi*x(:,odim-i+1)));
end
h(:,odim)=cos(0.5*pi*x(:,1));
s=2:2:2*odim;
s=ones(n,1)*s;
y=(x(:,odim)*ones(1,odim)+s.*h)';
   end
end
%%%%%%%
function p=wfg9(p,pdim,odim,k)
   p.name='WFG9';
   p.od=odim;
   p.pd=pdim;
   bu=(2:2:2*pdim)';
   p.domain=[zeros(pdim,1) bu];
   p.func=@evaluate;
   function y=evaluate(z)
     n=size(z,2);
     x=(z./bu)';
A=0.98/49.98;
B=0.02;
C=50;
for i=1:pdim-1
    y=x(:,i+1:pdim);
    Y=sum(y,2)/size(y,2);
    for j=1:size(Y,1)
        if Y(j)<0.5
            u(j,1)=Y(j)*((C-B)*A)*2+B;
        else
            u(j,1)=(Y(j)-0.5)*(C-((C-B)*A+B))*2+(C-B)*A+B;
        end
    end
    v=A-(1-2*u).*abs(floor(0.5-u)+A);
    t1(:,i)=x(:,i).^(B+(C-B)*v);
end
t1(:,pdim)=x(:,pdim);

A=0.35;
B=0.001;
C=0.05;
for i=1:k
    t2(:,i)=1+(abs(t1(:,i)-A)-B).*(floor(t1(:,i)-A+B)*(1-C+(A-B)/B)/(A-B)+floor(A+B-t1(:,i))*(1-C+(1-A-B)/B)/(1-A-B)+1/B);
end
A=30;
B=95;
C=0.35;
for i=k+1:pdim
    t2(:,i)=(1+cos((4*A+2)*pi*(0.5-(abs(t1(:,i)-C))./(2*(floor(C-t1(:,i))+C))))+4*B*(((abs(t1(:,i)-C))./(2*(floor(C-t1(:,i))+C))).^2))/(B+2);
end

for i=1:odim-1
    y=t2(:,(i-1)*k/(odim-1)+1:i*k/(odim-1));
    A=k/(odim-1);
    for j=1:size(y,2)
        s(:,j)=y(:,j);
        for p=0:A-2
            s(:,j)=s(:,j)+abs(y(:,j)-y(:,1+mod(j+p,size(y,2))));
        end
    end
    t3(:,i)=sum(s,2)/(size(y,2)/A*ceil(A/2)*(1+2*A-2*ceil(A/2)));
end
y=t2(:,k+1:end);
A=pdim-k;
for j=1:size(y,2)
    s(:,j)=y(:,j);
    for p=0:A-2
        s(:,j)=s(:,j)+abs(y(:,j)-y(:,1+mod(j+p,size(y,2))));
    end
end
t3(:,odim)=sum(s,2)/(size(y,2)/A*ceil(A/2)*(1+2*A-2*ceil(A/2)));
x=[];
for i=1:1
    x(:,i)=max(t3(:,odim),ones(n,1)).*(t3(:,i)-0.5)+0.5;
end
for i=2:odim-1
    x(:,i)=max(t3(:,odim),ones(n,1)).*(t3(:,i)-0.5)+0.5;
end
x(:,odim)=t3(:,odim);

h(:,1)=prod(sin(0.5*pi*x(:,1:odim-1)),2);
for i=2:odim-1
    h(:,i)=prod(sin(0.5*pi*x(:,1:odim-i)),2).*(cos(0.5*pi*x(:,odim-i+1)));
end
h(:,odim)=cos(0.5*pi*x(:,1));
s=2:2:2*odim;
s=ones(n,1)*s;
y=(x(:,odim)*ones(1,odim)+s.*h)';
   end
end
%%%%%%%
