function mop=lz(mop,testname,dimension )
%Get test multi-objective problems from a given name. 
%   The method get testing or benchmark problems for Multi-Objective
%   Optimization. The test problem will be encapsulated in a structure,
%   which can be obtained by function get_structure('testmop'). 
%   User get the corresponding test problem, which is an instance of class
%   mop, by passing the problem name and optional dimension parameters.
    switch lower(testname)
        case 'lz1'
            mop=lz1(mop, dimension);
        case 'lz2'
            mop=lz2(mop, dimension);
        case 'lz3'
            mop=lz3(mop, dimension);
        case 'lz4'
            mop=lz4(mop, dimension);
        case 'lz5'
            mop=lz5(mop, dimension);     
        case 'lz6'
            mop=lz6(mop, dimension); 
        case 'lz7'
            mop=lz7(mop, dimension); 
        case 'lz8'
            mop=lz8(mop, dimension); 
        case 'lz9'
            mop=lz9(mop, dimension);                                  
        otherwise 
            error('Undefined test problem name');                
    end 
end

%%

%%
function p = lz1(p,dim)
 p.name     = 'LZ1';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function y = evaluate(x)
    n       = size(x,1);
    io      = 3:2:n;
    ie      = 2:2:n;
    ss      = x - x(1).^(0.5+1.5*((1:1:n)'-2.0)/(n-2.0));
    y       = zeros(2,1);
    y(1)    = x(1) + 2.0/length(io)*sum(ss(io).^2.0);
    y(2)    = 1.0 - sqrt(x(1)) + 2.0/length(ie)*sum(ss(ie).^2.0);
end
end

%%
function p = lz2(p,dim)
 p.name     = 'LZ2';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [-ones(dim,1) ones(dim,1)]; p.domain(1,1) = 0.0;
 p.func     = @evaluate;
 
function y = evaluate(x)
    n       = size(x,1);
    io      = 3:2:n;
    ie      = 2:2:n;
    ss      = x - sin(6.0*pi*x(1)+(1:1:n)'*pi/n);
    y       = zeros(2,1);
    y(1)    = x(1) + 2.0/length(io)*sum(ss(io).^2.0);
    y(2)    = 1.0 - sqrt(x(1)) + 2.0/length(ie)*sum(ss(ie).^2.0);
end
end

%%
function p = lz3(p,dim)
 p.name     = 'LZ3';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [-ones(dim,1) ones(dim,1)]; p.domain(1,1) = 0.0;
 p.func     = @evaluate;
 
function y = evaluate(x)
    n       = size(x,1);
    io      = 3:2:n;
    ie      = 2:2:n;
    ss1     = x - 0.8*x(1)*cos(6.0*pi*x(1)+(1:1:n)'*pi/n);
    ss2     = x - 0.8*x(1)*sin(6.0*pi*x(1)+(1:1:n)'*pi/n);
    y       = zeros(2,1);
    y(1)    = x(1) + 2.0/length(io)*sum(ss1(io).^2.0);
    y(2)    = 1.0 - sqrt(x(1)) + 2.0/length(ie)*sum(ss2(ie).^2.0);
end
end

%%
function p = lz4(p,dim)
 p.name     = 'LZ4';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [-ones(dim,1) ones(dim,1)]; p.domain(1,1) = 0.0;
 p.func     = @evaluate;
 
function y = evaluate(x)
    n       = size(x,1);
    io      = 3:2:n;
    ie      = 2:2:n;
    ss1     = x - 0.8*x(1)*cos((6.0*pi*x(1)+(1:1:n)'*pi/n)/3.0);
    ss2     = x - 0.8*x(1)*sin(6.0*pi*x(1)+(1:1:n)'*pi/n);
    y       = zeros(2,1);
    y(1)    = x(1) + 2.0/length(io)*sum(ss1(io).^2.0);
    y(2)    = 1.0 - sqrt(x(1)) + 2.0/length(ie)*sum(ss2(ie).^2.0);
end
end

%%
function p = lz5(p,dim)
 p.name     = 'LZ5';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [-ones(dim,1) ones(dim,1)]; p.domain(1,1) = 0.0;
 p.func     = @evaluate;
 
function y = evaluate(x)
    n       = size(x,1);
    io      = 3:2:n;
    ie      = 2:2:n;
    ss1     = x - (0.3*x(1)*x(1)*cos(24.0*pi*x(1)+4.0*(1:1:n)'*pi/n)+0.6*x(1)).*cos(6.0*pi*x(1)+(1:1:n)'*pi/n);
    ss2     = x - (0.3*x(1)*x(1)*cos(24.0*pi*x(1)+4.0*(1:1:n)'*pi/n)+0.6*x(1)).*sin(6.0*pi*x(1)+(1:1:n)'*pi/n);
    y       = zeros(2,1);
    y(1)    = x(1) + 2.0/length(io)*sum(ss1(io).^2.0);
    y(2)    = 1.0 - sqrt(x(1)) + 2.0/length(ie)*sum(ss2(ie).^2.0);
end
end

%%
function p = lz6(p,dim)
 p.name     = 'LZ6';
 p.pd       = dim;
 p.od       = 3;
 p.domain   = [-2.0*ones(dim,1) 2.0*ones(dim,1)]; p.domain(1:2,1) = 0.0; p.domain(1:2,2) = 1.0;
 p.func     = @evaluate;
 
function y = evaluate(x)
    n       = size(x,1);
    i1      = 4:3:n;
    i2      = 5:3:n;
    i3      = 3:3:n;
    ss      = x - 2.0*x(2)*sin(2.0*pi*x(1)+(1:1:n)'*pi/n);
    y       = zeros(3,1);
    y(1)    = cos(0.5*pi*x(1))*cos(0.5*pi*x(2)) + 2.0/length(i1)*sum(ss(i1).^2.0);
    y(2)    = cos(0.5*pi*x(1))*sin(0.5*pi*x(2)) + 2.0/length(i2)*sum(ss(i2).^2.0);
    y(3)    = sin(0.5*pi*x(1))                  + 2.0/length(i3)*sum(ss(i3).^2.0);    
end
end

%%
function p = lz7(p,dim)
 p.name     = 'LZ7';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function y = evaluate(x)
    n       = size(x,1);
    io      = 3:2:n;
    ie      = 2:2:n;
    yy      = x - x(1).^(0.5+1.5*((1:1:n)'-2)/(n-2.0));
    ss      = 4*yy.*yy - cos(8*pi*yy) + 1.0;
    y       = zeros(2,1);
    y(1)    = x(1)              + 2.0/length(io)*sum(ss(io));
    y(2)    = 1.0 - sqrt(x(1))  + 2.0/length(ie)*sum(ss(ie));
end
end

%%
function p = lz8(p,dim)
 p.name     = 'LZ8';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function y = evaluate(x)
    n       = size(x,1);
    io      = 3:2:n;
    ie      = 2:2:n;
    yy      = x - x(1).^(0.5+1.5*((1:1:n)'-2)/(n-2.0));
    ss1     = yy.*yy;
    ss2     = cos(20*pi*yy./sqrt(1:1:n)');
    y       = zeros(2,1);
    y(1)    = x(1)              + 2.0/length(io)*(4*sum(ss1(io))-2*prod(ss2(io))+2);
    y(2)    = 1.0 - sqrt(x(1))  + 2.0/length(ie)*(4*sum(ss1(ie))-2*prod(ss2(ie))+2);
end
end

%%
function p = lz9(p,dim)
 p.name     = 'LZ9';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [-ones(dim,1) ones(dim,1)]; p.domain(1,1) = 0;
 p.func     = @evaluate;
 
function y = evaluate(x)
    n       = size(x,1);
    io      = 3:2:n;
    ie      = 2:2:n;
    ss      = x - sin(6*pi*x(1) + (1:1:n)'*pi/n);
    y       = zeros(2,1);
    y(1)    = x(1)              + 2.0/length(io)*sum(ss(io).^2);
    y(2)    = 1.0 - x(1).*x(1)  + 2.0/length(ie)*sum(ss(ie).^2);
end
end


