function [EvaPS,EvaPF]=moeadass(mop,params,sel)
%run MOEA/D-MTGP for the given mop.
%%
global itrCounter evalCounter;
while true
Restart=false;
%initialization
[ExistingEvaInds,Archive,subproblems,CosAngleMatrix]=init(mop,params);
EvaPS={};EvaPF={}; 
EvaPS{1,1}=[ExistingEvaInds.parameter]; EvaPF{1,1}=[ExistingEvaInds.objective];
StoreCounter=1;
%evolve
PreviousHyps=[];FalseTime=zeros(1,2);
while ~terminate(params)
    [NewEvaInds,NewHyps,subproblems,Archive,CosAngleMatrix,FalseTime]=evolve(mop,params,ExistingEvaInds,subproblems,CosAngleMatrix,Archive,PreviousHyps,FalseTime);
    if (evalCounter-size(EvaPS{1,1},2)>=StoreCounter*params.evaluation/sel)||terminate(params)
        StoreCounter=StoreCounter+1;
        EvaPS{1,StoreCounter}=[NewEvaInds.parameter];
        EvaPF{1,StoreCounter}=[NewEvaInds.objective];
    end
    PreviousHyps=NewHyps;ExistingEvaInds=NewEvaInds;
    itrCounter=itrCounter+1;
    updateplot(itrCounter,evalCounter,ExistingEvaInds);
    if FalseTime(1)>20
     Restart=true;
     warning('The algorithm is blocked by very poor initialization and will be restarted with new initialization');
     break;
    end 
end
if ~Restart
    break;
end
end
fprintf('Totally %.4f iterations are used in this run\n',itrCounter);
end
% The evoluation setp in MOEA/D-MTGP
function [NewEvaInds,NewHyps,subproblems,NewArchive,CosAngleMatrix,FalseTime]=evolve(mop,params,EvaInds,subproblems,CosAngleMatrix,Archive,PreviousHyps,FalseTime)
%% 1. Choose subproblems and initialize training data--------------------------------------------------------------------------
Selectdirections=prescreenDirections(params,CosAngleMatrix,Archive,subproblems);
[Xtrain,Ytrain,SelectSubps]=InitialTrainingData(Selectdirections,params,subproblems,Archive,EvaInds);
%% 2. GP/MoGP model training--------------------------------------------------------------------------
MTGP_model=learn_mtgp(Xtrain,Ytrain,params,PreviousHyps,FalseTime,mop,SelectSubps);%Hyper-parameter (theta) learning
%% 3. Optimization by GA------------------------------------------------------------------------------
CandInds=GA_optimizer(mop,params,SelectSubps,FalseTime,MTGP_model,Archive,EvaInds);%Optimization by GA
%% %%%%%%%%%%%%%%%%%%%------------>Information Update<------------%%%%%%%%%%%%%%%%%%%%%%%
global idealpoint;
if isempty(CandInds)
  FalseTime=FalseTime+1;
  NewEvaInds=EvaInds;
  NewArchive=Archive;
else
  FalseTime(1)=0;
  NewIdealpoint=idealpoint(:,2); 
  for i=1:length(CandInds)
      [v,ind]=evaluate(mop,CandInds(i));
      CandInds(i)=ind;
      NewIdealpoint=min(NewIdealpoint,v-(1e-6));
  end
  idealpoint(:,1)=idealpoint(:,2); idealpoint(:,2)=NewIdealpoint;    
  [NewEvaInds,NewArchive,subproblems,CosAngleMatrix]=updateData(EvaInds,CandInds,Archive,idealpoint,subproblems,CosAngleMatrix,Selectdirections);
  if isequal(NewArchive,Archive)
      FalseTime(2)=FalseTime(2)+1;
  else
      FalseTime(2)=0;
  end
end
NewHyps=[PreviousHyps;MTGP_model];
end
%% should be updated at most by this new individual.
function y=terminate(params)
    global evalCounter;
    y = (evalCounter>=params.evaluation);
end
%% should be updated at most by this new individual.
function updateplot(gen,evalC,ExistingEvaInds)
df      = [ExistingEvaInds.objective]; df = df';
ds      = [ExistingEvaInds.parameter]; ds = ds';
str     = sprintf('gen=%d evalC=%d', gen,evalC);

hold off; 
subplot(1,2,1);
if size(df,2) == 2
    plot(df(:,1), df(:,2), 'ro', 'MarkerSize',4);
    xlabel('f1', 'FontSize', 6);
    ylabel('f2', 'FontSize', 6);
    grid on;
else
    plot3(df(:,1), df(:,2), df(:,3), 'ro', 'MarkerSize',4);
    xlabel('f1', 'FontSize', 6);
    ylabel('f2', 'FontSize', 6);
    zlabel('f3', 'FontSize', 6);
    grid on;
end
title(str, 'FontSize', 8);
box on;
drawnow;

subplot(1,2,2);
if size(ds,2) >= 3
    plot3(ds(:,1), ds(:,2), ds(:,3), 'ro', 'MarkerSize',4);
    xlabel('x1', 'FontSize', 6);
    ylabel('x2', 'FontSize', 6);
    zlabel('x3', 'FontSize', 6);  
    grid on;
elseif size(ds,2) >= 2
    plot(ds(:,1), ds(:,2), 'ro', 'MarkerSize',4);
    xlabel('x1', 'FontSize', 6);
    ylabel('x2', 'FontSize', 6);
    grid on;
end
box on;
drawnow;
clear df ds;
end
