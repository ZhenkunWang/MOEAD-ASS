function Selectdirections=prescreenDirections(params,CosAngleMatrix,subproblems)
evalTimes=[subproblems.evalTimes];
[Npoints,Ndirs]=size(CosAngleMatrix); AverageRanks=zeros(Npoints,Ndirs);
for i=1:Npoints
    [~,FarthestIdx]=sort(CosAngleMatrix(i,:));
    AverageRanks(i,FarthestIdx)=(1:Ndirs)/Ndirs;
end
Fits=sum(AverageRanks.^100)+0.9*evalTimes;
% Fits=sum(exp(-400*(1-AverageRanks).^2));

SelectDirIdx=zeros(1,params.N_task); SelectNo=min(Ndirs,params.N_task);
[~,DirIxs]=min(Fits); SelectDirIdx(1)=DirIxs; Fits(DirIxs)=Inf;
PerRanks=zeros(1,Ndirs);
for i=2:SelectNo
    PerRanks(subproblems(DirIxs).neighbors)=(Ndirs:-1:1)/Ndirs;
    NewFits=Fits+PerRanks.^10;
    Fits=NewFits;
    [~,DirIxs]=min(Fits);   
    SelectDirIdx(i)=DirIxs;
    Fits(DirIxs)=Inf;
end
Selectdirections=SelectDirIdx;
end