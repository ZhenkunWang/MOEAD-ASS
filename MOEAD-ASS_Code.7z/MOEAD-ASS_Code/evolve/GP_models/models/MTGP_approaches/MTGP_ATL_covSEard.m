function K = MTGP_ATL_covSEard(hyp, x, z, i)
% Adaptive trasfer learning kernel for two tasks: target task and source task
% Squared Exponential covariance function with isotropic distance and scaling measure. 
%
% Ref. Cao B, Pan SJ, Zhang Y, Yeung DY, Yang Q, Adaptive transfer learning, AAAI, 2010
% Note that Wei et al. (2017-Source-target similarity modelings for multi-source transfer Gaussian process regression) has proved that the ATL
% method only works for two-task case.
%
% For two tasks, we have the kernel matix as
% K = [K_{TT},     rou*K_{TL}
%      rou*K_{LT}, K_{LL}      ]
%
% Based on the covSEisoU.m function of the GPML Toolbox - 
%   with the following changes:
%       - only elements of x(:,1:end-1)/z(:,1:end-1) will be analyzed, 
%       - x(:,end)/z(:,end) will be ignored, as it contains only the label information
%       - independent of the label all x values will have the same hyp
%       - output-scaling hyperparameter is fixed to 1
%
% The covariance function is parameterized as:
%
% k(x^p,x^q) = exp(-(x^p - x^q)'*inv(P)*(x^p - x^q)/2) 
%
% where the P matrix is ell^2 times the unit matrix.
% The hyperparameters are:
%
% hyp = [ rou
%         log(ell_1)
%         log(ell_2)
%          .
%         log(ell_D)
%         log(sqrt(sf2)) ]
%
% by Haitao Liu
% 2017/08/22

if nargin<2, K = 'D+2'; return; end                  % report number of parameters
if nargin<3, z = []; end                                   % make sure, z exists
xeqz = numel(z)==0; dg = strcmp(z,'diag') && numel(z)>0;        % determine mode

D = size(x(:,1:end-1),2) ;

rou = hyp(1) ; 
rou_s = [1,rou;rou,1] ;
ell = hyp(2:D+1);                                 % characteristic length scale
sf2 = hyp(D+2) ;

% precompute squared distances
if nargin < 4
  K = MTGP_covCC_chol_nD_Rou_my(rou_s,x,z).*MTGP_covSEard([ell,sf2],x,z) ;
else                                                               % derivatives
  if i == 1
	  K = MTGP_covCC_chol_nD_Rou_my([0,1;1,0],x,z).*MTGP_covSEard([ell,sf2],x,z) ;
  elseif i >= 2 && i <= D+2
	  K = MTGP_covCC_chol_nD_Rou_my(rou_s,x,z).*MTGP_covSEard([ell,sf2],x,z,i-1) ;
  else
    error('Unknown hyperparameter')
  end
end