function K = MTGP_covSEard_ProConv_Mtasks(hyp, x, z, u)
% Process covolution to create valid covariance functions
% see, A. Melkumyan and F. Ramos, “Multi-kernel Gaussian processes,�? in Proc. Int. Joint Conf. Artif. Intell., Barcelona, Spain, 2011, pp. 1408–1413
% The cross-covariance function between task i and task j is expressed as
%
% K(x_i,x'_j) = \int g_i(x_i - u)g_j(x'_j - u) du
%
% where g_i and g_j are the smoothing kernels.
% Squared Exponential covariance function with Automatic Relevance Detemination (ARD) distance measure. The covariance function is parameterized as:
%
% k(x^p,x^q) = sf2 * exp(-(x^p - x^q)'*inv(P)*(x^p - x^q)/2)
%
% where the P matrix is diagonal with ARD parameters ell_1^2,...,ell_D^2, where
% D is the dimension of the input space and sf2 is the signal variance. 
% Then, the cross covariance terms using Squared Exponential \times Squared Exponential can be expressed as
%
% K_{SE1 \times SE2}(x,x';P1,sf2_1,P2;sf2_2) = sf2_1*sf2_2 * 2^(dim/2) * [|P1|^0.25*|P2|^0.25] / [|P1+P2|^0.5]
%                                            * exp[-(x-x')'*inv(P1+P2)*(x-x')] 
%
% The self covaraicne function is the same as the original Squared Exponential function.
% Finally, the whole covariance matrix is expressed as
%
% K = K_f*K_pc
%
% whre K_f is the task matrix built by the free-form strategy proposed by Bonallia.
% the K_pc built by process convolution for 2-task case is
%
% K_pc = [K_11 K_12; K_21 K_22]
%
% where K_ii is built by original SE function, and K_ij us built by the cross-covariance expression.
% The hyperparameters for the cross covariance structure are:
%
% hyp = [ (theta_c,1)
%         (theta_c,2)
%           ...
%         (theta_c,k)
%         log(ell1_1)
%         log(ell1_2)
%          .
%         log(ell1_D)
%         log(sqrt(sf2_1))
%         log(ell2_1)
%         log(ell2_2)
%          .
%         log(ell2_D)
%         log(sqrt(sf2_2)) ]
%
% Copyright (c) by Carl Edward Rasmussen and Hannes Nickisch, 2010-09-10.
%
% See also COVFUNCTIONS.M.
%
% Modified by Haitao Liu 2017/07/27
% Here, x = [x, l] \in R^{n*(D+1)} where l is the task indicator

if nargin<2, K = 'sum([1:nL])+nL*(D+1)'; return; end           % report number of parameters
if nargin<3, z = []; end                                        % make sure, z exists
xeqz = numel(z)==0; dg = strcmp(z,'diag') && numel(z)>0;        % determine mode

[n,D] = size(x(:,1:end-1)) ;                                      % dimensionality
nL = max(x(:,end));                                             % number of tasks
T = sum([1:nL]) ;                                               % number of paras in task matrix K_f

rou   = hyp(1:T) ;                                              % paras for free-form K_f
for i = 1:nL
    ell{i} = hyp((i-1)*(D+1)+1+T:(i-1)*(D+1)+T+D) ;
    sf2{i} = hyp((i-1)*(D+1)+T+D+1) ;
end                                         

if nargin < 4                                                   % covariance matrix
  % diagonal blocks
  for i = 1:nL 
      Kf = zeros(nL,nL) ; Kf(i,i) = 1 ;
      if i == 1
        K0 = MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard([ell{i};sf2{i}],x,z) ;
      else
        K0 = K0 + MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard([ell{i};sf2{i}],x,z) ;
      end
  end
  % off-diagonal blocks
  for i = 2:nL 
      for j = 1:i-1
          Kf = zeros(nL,nL) ; Kf(i,j) = 1 ; Kf(j,i) = 1 ;
          K0 = K0 + MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard_CONV([ell{i};ell{j};sf2{i};sf2{j}],x,z) ; 
      end
  end
  % consider task similarity matrix
  K = MTGP_covCC_chol_nD(rou,x,z).*K0 ;
else                                                            % derivatives
  if u <= T
      % diagonal blocks
      for i = 1:nL 
          Kf = zeros(nL,nL) ; Kf(i,i) = 1 ;
          if i == 1
            K0 = MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard([ell{i};sf2{i}],x,z) ;
          else
            K0 = K0 + MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard([ell{i};sf2{i}],x,z) ;
          end
      end
      % off-diagonal blocks
      for i = 2:nL 
          for j = 1:i-1
              Kf = zeros(nL,nL) ; Kf(i,j) = 1 ; Kf(j,i) = 1 ;
              K0 = K0 + MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard_CONV([ell{i};ell{j};sf2{i};sf2{j}],x,z) ; 
          end
      end
	  K = MTGP_covCC_chol_nD(rou,x,z,u).*K0 ;
  elseif u >= T+1 && u <= nL*(D+1)+T
      index = ceil((u - T)/(D+1)) ;
      index_add = (u-T) - (index-1)*(D+1) ;
      
      % derivates of diagonal blocks
      Kf = zeros(nL,nL) ; Kf(index,index) = 1 ;
      dK0 = MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard([ell{index};sf2{index}],x,z,index_add) ;
      
      % derivates of off-diagonal blocks
      if index == 1
         for i = 2:nL
           Kf = zeros(nL,nL) ; Kf(i,index) = 1 ; Kf(index,i) = 1 ; 
           if index_add <= D
             dK0 = dK0 + MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard_CONV([ell{i};ell{index};sf2{i};sf2{index}],x,z,index_add+D) ;
           elseif index_add == D+1
             dK0 = dK0 + MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard_CONV([ell{i};ell{index};sf2{i};sf2{index}],x,z,2*D+2) ; 
           end
         end
       elseif index == nL
         for j = 1:index-1
           Kf = zeros(nL,nL) ; Kf(index,j) = 1 ; Kf(j,index) = 1 ;
           if index_add <= D
               dK0 = dK0 + MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard_CONV([ell{index};ell{j};sf2{index};sf2{j}],x,z,index_add) ;
           elseif index_add == D+1 
               dK0 = dK0 + MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard_CONV([ell{index};ell{j};sf2{index};sf2{j}],x,z,2*D+1) ;
           end
         end
      else
         for j = 1:index-1
           Kf = zeros(nL,nL) ; Kf(index,j) = 1 ; Kf(j,index) = 1 ;
           if index_add <= D
               dK0 = dK0 + MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard_CONV([ell{index};ell{j};sf2{index};sf2{j}],x,z,index_add) ;
           elseif index_add == D+1 
               dK0 = dK0 + MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard_CONV([ell{index};ell{j};sf2{index};sf2{j}],x,z,2*D+1) ;
           end
         end 

         for i = 2:nL
           Kf = zeros(nL,nL) ; Kf(i,index) = 1 ; Kf(index,i) = 1 ; 
           if index_add <= D
             dK0 = dK0 + MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard_CONV([ell{i};ell{index};sf2{i};sf2{index}],x,z,index_add+D) ;
           elseif index_add == D+1
             dK0 = dK0 + MTGP_covCC_chol_nD_Rou_my(Kf,x,z).*MTGP_covSEard_CONV([ell{i};ell{index};sf2{i};sf2{index}],x,z,2*D+2) ; 
           end
         end
      end

	  K = MTGP_covCC_chol_nD(rou,x,z).*dK0 ;
  else
    error('Unknown hyperparameter')
  end
end