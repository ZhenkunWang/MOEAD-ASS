function K = MTGP_CoMOGP_covSEard_Mtasks(hyp, x, z, i)
% Collaborative multi-output Gaussian process
% Generalized kernel in MFGP for M tasks
% Ref. Nguyen T V, Bonilla E V. Collaborative Multi-output Gaussian Processes[C]//UAI. 2014: 643-652.
% Squared Exponential covariance function with Automatic Relevance Detemination (ARD) distance measure for MTGP with common-residual decomposition
% 
% For d outputs {f_i} (1 <= i <= d), we express them as
%    f_i = a_i*u_c + u_{r,sep}^i
% where u_c, u_{r,share}, and u_{r,sep}^i are independent Gaussian processes with zero mean.
% Then the covariance is
%    cov(f_i,f_{i'}) = a_i*a_{i'}*k_c(x_i,x_{i'}) + k^{i}_{r,sep}(x_i,x_{i'}), for i == i'
%                    = a_i*a_{i'}*k_c(x_i,x_{i'}),                             for i ~= i'
%
% For the task coeffients {a_i}, we employ the free-from approach to construct the task matrix K_f = LL^T as proposed by Bonilla et al. 2007 using a 
% Cholesky decomposition to assure that the matrix is positive definite
%
% hyperparameters in MTGP_covCC_chol_nD.m are the elements of the lower triangula matrix L in the order 
% of:
%           theta_c,1       0               0                       0
%   L   = [ theta_c,2       theta_3         0               ...     0           ]
%               ...
%           theta_c,k-m+1   theta_c,k-m+2   theta_c,k-m+3   ...    theta_c,k
%
% Only elements of x(:,end)/z(:,end) will be analyzed, residual columns will be ignored. 
% x(:,end)/z(:,end) contain the label information of the feature

% For k_c, and k_{r,sep}^i, we choose the SE kernel with ARD (MTGP_covSEard.m). MTGP_covSEard.m is based on the covSEard.m function of 
% the GPML Toolbox with the following changes:
%       - only elements of x(:,1:end-1)/z(:,1:end-1) will be analyzed, 
%       - x(:,end)/z(:,end) will be ignored, as it contains only the label information
%
% k(x^p,x^q) = sf2 * exp(-(x^p - x^q)'*inv(P)*(x^p - x^q)/2)
%
% where the P matrix is diagonal with ARD parameters ell_1^2,...,ell_D^2, where
% D is the dimension of the input space and sf2 is the signal variance.
%
% Finally, all the hyperparameters for this composite covariance function are:
%
% hyp = [ (theta_c,1)      % paras for K_f
%         (theta_c,2)
%           ...
%         (theta_c,k)
%         log(ell1_1)      % paras for k_c
%         log(ell1_2)
%          ...
%         log(ell1_D)
%         log(sqrt(sf2_1))
%         log(ell2_1)      % paras for k^{i}_{r,sep}
%         log(ell2_2)
%          ...
%         log(ell2_D)
%         log(sqrt(sf2_2))
%         log(ell3_1)      % paras for k^{i'}_{r,sep}
%         log(ell3_2)
%          ...
%         log(ell3_D)
%         log(sqrt(sf2_3))
%         coef]            % coefficient para between k_{r,share} and k_{r,sep}
% Note that here we only construct the covarance function for up to TWO tasks (i = 2).
%
% by Haitao Liu
% 2017/03/02

if nargin<2, K = 'sum([1:nL])+(1+nL)*(D+1)'; return; end          % report number of parameters
if nargin<3, z = []; end                                          % make sure, z exists
xeqz = numel(z)==0; dg = strcmp(z,'diag') && numel(z)>0;          % determine mode

D = size(x(:,1:end-1),2) ;                                        % dimensionality
nL = max(x(:,end));                                               % number of tasks
T = sum(1:nL) ;                                                 % number of paras in task matrix K_f

rou   = hyp(1:T) ;                                                % paras for free-form K_f
ell{1}  = hyp(T+1:T+D);                                           % common para: characteristic length scale
sf2{1} = hyp(T+D+1) ;                                             % common para: signal variance
for j = 1:nL
    ell{j+1} = hyp(T+D+1+(j-1)*(D+1)+1:T+2*D+(j-1)*(D+1)+1) ; % residual sep para: characteristic length scale
    sf2{j+1} = hyp(T+2*D+(j-1)*(D+1)+1+1) ;                     % residual sep para: signal variance
end

A = zeros(nL,nL) ;                                                % prepared for diagonal identy matrix                                             
if nargin < 4                                                     % covariance matrix
    for j = 1:1
        A_j = A ; A_j(j,j) = 1 ;
        K_sep = MTGP_covCC_chol_nD_Rou_my(A_j,x,z).*MTGP_covSEard([ell{j+1};sf2{j+1}],x,z) ;
    end
    for j = 2:nL
        A_j = A ; A_j(j,j) = 1 ;
        K_sep = K_sep + MTGP_covCC_chol_nD_Rou_my(A_j,x,z).*MTGP_covSEard([ell{j+1};sf2{j+1}],x,z) ;        
    end                                                  
    K = MTGP_covCC_chol_nD(rou,x,z).*MTGP_covSEard([ell{1};sf2{1}],x,z) + K_sep ;
else                                                              % derivatives
    if i <= T % derivatives w.r.t. Kf
	    K = MTGP_covCC_chol_nD(rou,x,z,i).*MTGP_covSEard([ell{1};sf2{1}],x,z) ;
    elseif i >= T+1 && i <= T+D+1 % derivatives w.r.t. Kc
	    K = MTGP_covCC_chol_nD(rou,x,z).*MTGP_covSEard([ell{1};sf2{1}],x,z,i-T) ;
    elseif i >= T+D+2 && i <= T+(nL+1)*(D+1) % derivatives w.r.t. K_sep
        index = ceil((i - (T+D+1)) / (D+1)) ;
        A_index = A ; A_index(index,index) = 1 ;
        start_i = T+D+1+(index-1)*(D+1) ;
        K = MTGP_covCC_chol_nD_Rou_my(A_index,x,z).*MTGP_covSEard([ell{index+1};sf2{index+1}],x,z,i-start_i) ; 
    else
        error('Unknown hyperparameter')
    end
end