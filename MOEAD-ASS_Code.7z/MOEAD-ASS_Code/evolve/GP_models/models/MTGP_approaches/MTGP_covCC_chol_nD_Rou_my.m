function K = MTGP_covCC_chol_nD_Rou_my(hyp,x, z)
% 
% Generates a "free-form" cross correlation covariance matrix as proposed 
% by Bonilla et al. 2007 using a Cholesky decomposition to assure that the
% matrix is positive definite
%
% hyperparameters are the elements of the lower triangula matrix L in the order 
% of:
%           theta_c,1       0               0                       0
%   L   = [ theta_c,2       theta_3         0               ...     0           ]
%               ...
%           theta_c,k-m+1   theta_c,k-m+2   theta_c,k-m+3   ...    theta_c,k
%
% Parametrization is as discribed "Tutorial on Multi-Task Gaussian
% Processes for biomedical applications"
%
% Only elements of x(:,end)/z(:,end) will be analyzed, residual columns will be ignored. 
% x(:,end)/z(:,end) contain the label information of the feature
%
% Derivatives are implemented and hypperparameters can be optimized via gradient descent
% (So far only tested up to nL 4)
%
% by Robert Duerichen
% 04/02/2014
%
% hyp = [   (theta_c,1)
%           (theta_c,2)
%           ...
%           (theta_c,k)]
%

%if nargin<2, K = ['sum([1:nL])']; return; end       % report number of parameters
if nargin<3, z = []; end                                    % make sure, z exists
xeqz = numel(z)==0; dg = strcmp(z,'diag') && numel(z)>0;    % determine mode


% create index for hyp in matrix L
K_f = hyp;

% precompute squared distances  
if dg                                                               % vector kxx
    K = corr_nd(x(:,end), x(:,end),K_f); 
    K = diag(K);
else
    if xeqz                                                 % symmetric matrix Kxx
        K = corr_nd(x(:,end), x(:,end),K_f); 
    else
        K = corr_nd(x(:,end), z(:,end),K_f);
    end
end



