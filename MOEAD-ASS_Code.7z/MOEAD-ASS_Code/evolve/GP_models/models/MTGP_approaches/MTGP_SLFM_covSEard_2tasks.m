function K = MTGP_SLFM_covSEard_2tasks(hyp, x, z, u)
% semiparametric latant factor model (SLFM) (Q = 2)
%
% Squared Exponential covariance function with isotropic distance and scaling
% measure. 
%
% Based on the covSEisoU.m function of the GPML Toolbox - 
%   with the following changes:
%       - only elements of x(:,1:end-1)/z(:,1:end-1) will be analyzed, 
%       - x(:,end)/z(:,end) will be ignored, as it contains only the label information
%       - independent of the label all x values will have the same hyp
%       - output-scaling hyperparameter is fixed to 1
%
% The covariance function is parameterized as:
%
% k(x^p,x^q) = exp(-(x^p - x^q)'*inv(P)*(x^p - x^q)/2) 
%
% where the P matrix is ell^2 times the unit matrix.
% The hyperparameters are:
%
% hyp = [ (theta_c,1)
%         (theta_c,2)
%           ...
%         (theta_c,k)
%         log(ell1_1)
%         log(ell1_2)
%          .
%         log(ell1_D)
%         log(sqrt(sf2_1))]
%
% by Haitao Liu
% 2017/07/27

if nargin<2, K = '2*sum([1:nL])+2*(D+1)'; return; end                  % report number of parameters
if nargin<3, z = []; end                                   % make sure, z exists
xeqz = numel(z)==0; dg = strcmp(z,'diag') && numel(z)>0;        % determine mode

[n,D] = size(x(:,1:end-1)) ;
nL = max(x(:,end));

T = sum(1:nL) ;
for i = 1:2
  rou{i} = hyp(1+(i-1)*(T+D+1):(i-1)*(T+D+1)+T) ;
  ell{i} = hyp((i-1)*(T+D+1)+T+1:(i-1)*(T+D+1)+T+D) ;
  sf2{i} = hyp((i-1)*(T+D+1)+T+D+1) ;
end

% precompute squared distances
if nargin < 4
  for i = 1:2
    if i == 1
      K = MTGP_covCC_chol_nD(rou{i},x,z).*MTGP_covSEard([ell{i};sf2{i}],x,z) ; % initialize
    else
      K = K + MTGP_covCC_chol_nD(rou{i},x,z).*MTGP_covSEard([ell{i};sf2{i}],x,z) ;
    end 
  end
else                                                               % derivatives
  if u <= 2*(T+D+1)
	  index = ceil(u/(T+D+1)) ;
    index_add = u - (index-1)*(T+D+1) ;

    if index_add <= T
      K = MTGP_covCC_chol_nD(rou{index},x,z,index_add).*MTGP_covSEard([ell{index};sf2{index}],x,z) ; 
    elseif index_add > T
      K = MTGP_covCC_chol_nD(rou{index},x,z).*MTGP_covSEard([ell{index};sf2{index}],x,z,index_add-T) ;  
    end
  else
    error('Unknown hyperparameter')
  end
end