function [post, nlZ, dnlZ] = MTGP_infExact_diffsn2_my(hyp, meanFun, cov, lik, x, y)

% Exact inference for a GP with Gaussian likelihood. Compute a parametrization
% of the posterior, the negative log marginal likelihood and its derivatives
% w.r.t. the hyperparameters. See also "help infMethods".
%
% Copyright (c) by Carl Edward Rasmussen and Hannes Nickisch, 2013-01-21
%
% See also INFMETHODS.M.

if iscell(lik), likstr = lik{1}; else, likstr = lik; end
if ~ischar(likstr), likstr = func2str(likstr); end
%if ~strcmp(likstr,'likGauss')               % NOTE: no explicit call to likGauss
%if ~strcmp(likstr,'likGauss_my')               % NOTE: no explicit call to likGauss
if ~strcmp(likstr,'likGauss_diffsn2_my')               % NOTE: no explicit call to likGauss
  error('Exact inference only possible with Gaussian likelihood');
end

x_val=x(:,1:end-1);
task_index = x(:,end);
[n, D] = size(x_val);
%% these lines have to be added to be able to use Lab_covCC_chol_nD function
if size(x,2) > 1
    nL = length(unique(task_index));
end

%KK = MTGP_covSEard_ProConv3(hyp.cov(4:end), x); 
%KKK = MTGP_covSEconU(hyp.cov(4:end), x);
%KK-KKK

K = feval(cov{:}, hyp.cov, x);                      % evaluate covariance matrix
% m = feval(meanFun{:}, hyp.mean, x_val);                          % evaluate mean vector
[m,dm] = feval(meanFun{:}, hyp.mean, x_val);           % evaluate mean vector and deriv


%sn2 = exp(2*hyp.lik);                               % noise variance of likGauss
sn2 = diag(exp(2*hyp.lik));                          % noise variance of likGauss
if nL==1
    sn2 = eye(n)*sn2;
else
    sn2 = diag(diag(sn2(task_index,task_index)));
end
%L = chol(K/sn2+eye(n));               % Cholesky factor of covariance with noise
%L = chol(K+sn2*eye(n));               % Cholesky factor of covariance with noise
L = chol(K+sn2);               % Cholesky factor of covariance with noise
alpha = solve_chol(L,y-m);

post.alpha = alpha;                            % return the posterior parameters
%post.sW = ones(n,1)/sqrt(sn2);                  % sqrt of noise precision vector
post.sW = sn2;                  % sqrt of noise precision vector
post.L  = L;                                        % L = chol(eye(n)+sW*sW'.*K)

if nargout>1                               % do we want the marginal likelihood?
  %nlZ = (y-m)'*alpha/2 + sum(log(diag(L))) + n*log(2*pi*sn2)/2;  % -log marg lik
  nlZ = (y-m)'*alpha/2 + sum(log(diag(L))) + n*log(2*pi)/2;  % -log marg lik 
  
  %##########
  %if hyp.cov(end)<0.001 || hyp.cov(end)>0.999
  %    nlZ = 10000 ;
  %end
  %##########
  
  if nargout>2                                         % do we want derivatives?
    dnlZ = hyp;                                 % allocate space for derivatives
    %Q = solve_chol(L,eye(n))/sn2 - alpha*alpha';    % precompute for convenience
	Q = solve_chol(L,eye(n)) - alpha*alpha';    % precompute for convenience
    for i = 1:numel(hyp.cov)
      dnlZ.cov(i) = sum(sum(Q.*feval(cov{:}, hyp.cov, x, [], i)))/2;
    end
    %dnlZ.lik = sn2*trace(Q);
    % nL = length(hyp.lik);
if nL==1
     dlik = eye(n)*2*exp(2*hyp.lik);
     dnlZ.lik = sum(sum(Q.*dlik))/2;
else
	for i = 1:nL
	  dlik = diag(zeros(1,nL));
	  dlik(i,i) = 2*exp(2*hyp.lik(i)); 
	  dlik = diag(diag(dlik(task_index,task_index)));
	  dnlZ.lik(i) = sum(sum(Q.*dlik))/2;
	  %dnlZ.lik(i) = 0.5*trace(Q*dlik) ;
	end
end
%     for i = 1:numel(hyp.mean)
%       dnlZ.mean(i) = -feval(meanFun{:}, hyp.mean, x_val, i)'*alpha;
%     end
    dnlZ.mean = -dm(alpha);
  end
end
