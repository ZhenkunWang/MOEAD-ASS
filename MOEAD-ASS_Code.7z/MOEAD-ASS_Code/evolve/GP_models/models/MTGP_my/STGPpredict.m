function [m,s2] = STGPpredict(S_test,model)

Ss_test{1} = S_test ;
[m_cell,s2_cell] = MTGP_freeform_predict(Ss_test,[],model) ;
m = m_cell{1} ; s2 = s2_cell{1} ;

end % end main function