function model = MTGP_freeform_fit(S,Y,GPfunc,meanfunc,covfunc,likfunc,inffunc,hyp,optSet)
% Construct a multi-task GP model
% Inputs:
%         S: a cell in which S{i} represents the sampled points for the ith task.
%            Note: sampled points should be nomalized into [0,1]^d
%         Y: a cell in which Y{i} represents the responses of the sampled points S{i} for the ith task
%         meanfunc: mean function specified for GP
%         covfunc: covariance function specified for GP, usually has the form KfKc where Kf is the task similarity matrix,
%                  and Kc is the typical convariance matrix.
%                  the hyperparameters thus come from the parameters in Kf and parameters in Kc
%         likfunc: likelihood function specified for GP
%         inffunc: inference method specified for GP, default is @MTGP_infExact
%         hyp: initial hyperparameters
%         optSet: a structural array containing the hypaprameter optimization settings
%                 .optimize: 'on' - infer hyparameters by minimizing NLML(negative log marginal likelihood)
%                            'off' - use provided hyparameters
%                 .Xnorm: 'Y' - normilize as (X-mean(X))/std(X)
%                 .Ynorm: 'Y' - normilize as (Y-mean(Y))/std(Y)
%                 .method: optimization algorithm include "GradientDesecnt" and "fmincon"
%                 .numOptFC: number of function calls for minimize.m
%                 .restarts: 1 - optimization runs with different start points
%                            0 - a single optimization run
% Outputs:
%         model: a structure containing the obtained parameters for a GP model
% By H.T. Liu 2017/01/20

num_task = length(S);           % number of tasks
dim = size(S{1},2) ;

%% generate training and test data with labels 
% x_train is a n*2 matrix, where n = \sum_{i=1}^{m}n_i is the number of points for m tasks. 
%         The first column in x_train is the training points, while the second column is the indics of the task
% y_train is a n*1 vector
x_train = [] ; y_train = [] ;
x_train_mean = zeros(num_task,dim) ;
x_train_std  = ones(num_task,dim) ;
y_train_mean = zeros(num_task,1) ;
y_train_std  = ones(num_task,1) ;
for i = 1:num_task
    if strcmp(optSet.Xnorm,'Y')
	    x_train_mean(i,:) = mean(S{i}) ;
	    x_train_std(i,:)  = std(S{i}) ;
    end
	x = [(S{i}-repmat(x_train_mean(i,:),size(S{i},1),1))./ repmat(x_train_std(i,:),size(S{i},1),1), i*ones(size(S{i},1),1)] ;	
    x_train = [x_train;x];
	
    if strcmp(optSet.Ynorm,'Y')
	    y_train_mean(i) = mean(Y{i}) ;
	    y_train_std(i)  = std(Y{i}) ;
    end
	y = (Y{i}-y_train_mean(i))/y_train_std(i) ;
    y_train = [y_train;y] ;
end

%% optimize hyperparameters and train model
numOptFC = optSet.numOptFC ;
if strcmp(optSet.optimize,'on')
    switch optSet.method
    	case 'GradientDescent'
    		if optSet.restarts == 0
    			% optimize
                results.hyp = minimize(hyp, GPfunc, -numOptFC, inffunc, meanfunc, covfunc, likfunc, x_train, y_train);
                % train
                [results.nlml, results.dnlZ] = feval(GPfunc, results.hyp, inffunc, meanfunc, covfunc, likfunc, x_train, y_train);
            elseif optSet.restarts == 1
                % now it is only used for MTGP with common-residual decomposition
            	% mainly because the balance coefficient affects the performance greatly
    
                % optSet 1
                coefs = 0:0.1:1;
                %coefs = 0.5 ;

                % optSet 2
                %n_repts = 10 ;
                %n_cov = length(hyp.cov) ; n_lik = length(hyp.lik) ;
                % lhs
                %hyps = lhsdesign(n_repts,n_cov+n_lik).*repmat((optSet.ub-optSet.lb),n_repts,1) + repmat(optSet.lb,n_repts,1) ;
                % tplhs
                %seed = zeros(1,n_cov+n_lik) ;
                %hyps = (tplhsdesign(n_repts, n_cov+n_lik, seed, 1)-1)/(n_repts-1).*repmat((optSet.ub-optSet.lb),n_repts,1) + repmat(optSet.lb,n_repts,1) ;
    
                parallel_stats = 'off' ; % due to unknown reason, it often leads to WRONG results using parallelization fashion
                if strcmp(parallel_stats,'off')
                    % 1
                    for i = 1:length(coefs)                                   
                        hyp_i = hyp ; hyp_i.cov(end) = coefs(i) ;
    
                    % 2
                    %for i = 1:n_repts                  
                        %hyp_i = hyp ;
                        %hyp_i.cov = hyps(i,1:n_cov) ;
                        %hyp_i.lik = hyps(i,n_cov+1:end)' ;
    
                        % optimize
                        results.hyp{i} = minimize(hyp_i, GPfunc, -numOptFC, inffunc, meanfunc, covfunc, likfunc, x_train,y_train);
                        % train
                        [results.nlml(i), results.dnlZ{i}] = feval(GPfunc,results.hyp{i}, inffunc, meanfunc, covfunc, likfunc, x_train, y_train);
                    
                        fprintf('No. optimizaiton: %d, NLML: %d, coef: %d, coef_opt: %d. \n', i, results.nlml(i), coefs(i),results.hyp{i}.cov(end)) ;
                        %fprintf('No. optimizaiton: %d, NLML: %d. \n', i, results.nlml(i)) ;
                    end
                elseif strcmp(parallel_stats,'on')
                    N_par = length(hyp.cov) + length(hyp.lik) ;
                    N_coefs = length(coefs) ;
                    hyp_vector = zeros(N_coefs,N_par) ;
                    nlml_my = zeros(N_coefs,1) ;
                    dnlZ_my = zeros(N_coefs,N_par) ;
                    parfor i = 1:N_coefs
                        hyp_i = hyp ; hyp_i.cov(end) = coefs(i) ;
                        % optimize
                        hyp_opt = minimize(hyp_i, GPfunc, -numOptFC, inffunc, meanfunc, covfunc, likfunc, x_train,y_train);
                        hyp_vector(i,:) = [hyp_opt.cov,hyp_opt.lik'] ;
                        % train
                        [nlml_my(i),dnlZ_opt] = feval(GPfunc,hyp_opt, inffunc, meanfunc, covfunc, likfunc, x_train, y_train);
                        dnlZ_my(i,:) = [dnlZ_opt.cov,dnlZ_opt.lik'] ;
                    end
                    for i = 1:N_coefs
                        hyp_now.cov = hyp_vector(i,1:length(hyp.cov)) ; hyp_now.lik = hyp_vector(i,end-1:end)' ;
                        results.hyp{i} = hyp_now ;
                        results.nlml(i) = nlml_my(i) ;
                        dnlZ_now.cov = dnlZ_my(i,1:length(hyp.cov)) ; dnlZ_now.lik = dnlZ_my(i,end-1:end)' ;
                        results.dnlZ{i} = dnlZ_now ;
                    end
                end
    
                % find best  nlml
                [results.nlml, best_hyp] = min(results.nlml);
                results.hyp = results.hyp{best_hyp};
                results.dnlZ = results.dnlZ{best_hyp} ;
    		end
        case 'fmincon'
        	% optimize
        	results.hyp = hypOpt(hyp,GPfunc,numOptFC,inffunc,meanfunc,covfunc,likfunc,x_train,y_train);
        	% train
            [results.nlml, results.dnlZ] = feval(GPfunc,results.hyp, inffunc, meanfunc, covfunc, likfunc, x_train, y_train);
    end
elseif strcmp(optSet.optimize,'off')
    % use provided hyperparameters
    results.hyp = hyp ;
    % train
    [results.nlml, results.dnlZ] = feval(GPfunc,results.hyp, inffunc, meanfunc, covfunc, likfunc, x_train, y_train);
end


%% compute resulting K_f matrix
%vec_dim = [1:num_task];
%L = zeros(num_task,num_task);
%for cnt_dim = 1:num_task
%    L(cnt_dim,1:vec_dim(cnt_dim)) = [results.hyp.cov(sum(vec_dim(1:cnt_dim-1))+1:sum(vec_dim(1:cnt_dim-1))+vec_dim(cnt_dim))];
%end

%results.K_f =  L*L';


%% export model
model = results ;
model.S = S ;
model.Y = Y ;
model.x_train = x_train ;
model.y_train = y_train ;
model.x_train_mean = x_train_mean ;
model.x_train_std = x_train_std ;
model.y_train_mean = y_train_mean ;
model.y_train_std = y_train_std ;
model.GPfunc = GPfunc ;
model.meanfunc = meanfunc ;
model.covfunc = covfunc ;
model.likfunc = likfunc ;
model.inffunc = inffunc ;
model.optSet = optSet ;
model.num_task = num_task ;

end % end main function