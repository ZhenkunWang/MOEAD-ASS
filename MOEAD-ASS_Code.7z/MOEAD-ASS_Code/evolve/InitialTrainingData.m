function [Xtrain,Ytrain,SelectSubps]=InitialTrainingData(Selectdirections,params,subproblems,Archive,ExistingEvaInds)
% [Xtrain,Ytrain,kx_idx,kf_idx,SelectSubps]=InitialTrainingData(Selectdirections,params,subproblems,Archive,ExistingEvaInds) 
% Generates data for training MTGP model
%
% INPUT:
% - Selectdirections : Selected Direction vectors
% - params           : Parameters
% - subproblems      : subproblems
% - Archive          : Archive Solution Indexes
% - ExistingEvaInds  : Evaluated Solutions
%
% OUTPUT:    
% - X            : Training inputs
% - Y            : Training target values
% - SelectIdxes  : The indexes of the selected solutions from the evaluated
%                  solution set
% - SelectSubps  : Selected Supproblems
InitialX=[ExistingEvaInds.parameter];InitialObjVals=[ExistingEvaInds.objective];
Npoints=length(ExistingEvaInds);SelectSubps=subproblems(Selectdirections);
%%
if strcmp(params.ModelMethod,'TrGP')
    Xtrain=cell(1,params.N_obj);
    Ytrain=Xtrain;
    if params.TrainSize>=Npoints
        Xtrain=repmat({InitialX'},1,params.N_obj);
        Ytrain=num2cell(InitialObjVals',1); 
    else    
        N_SelectIdxes=params.TrainSize;
        N_SelectIdxes_greedy=ceil(0.9*params.TrainSize);
        [~,Idxes]=sort(InitialObjVals,2);
        SelectIdxes_greedy=Idxes(:,1:N_SelectIdxes_greedy);
        for i=1:params.N_obj
            RemainIdxes=setdiff(1:Npoints,SelectIdxes_greedy(i,:));
            SelectIdxes=[SelectIdxes_greedy(i,:),RemainIdxes(randperm(length(RemainIdxes),N_SelectIdxes-length(SelectIdxes_greedy)))];
            Xtrain{1,i}=InitialX(:,SelectIdxes).';
            Ytrain{1,i}=InitialObjVals(i,SelectIdxes)';
        end
    end
else
    Xtrain=cell(1,params.N_task);
    Ytrain=Xtrain;
end
%% update SubpObjs
for i=1:params.N_task
    submin=SelectSubps(i).subpmin;
    subjs=SelectSubps(i).subpobjs;
    if ~isinf(submin)
        ObjVals=InitialObjVals(:,length(subjs)+1:end);
    else
        ObjVals=InitialObjVals; subjs=[];
    end
    objs=subobjective(SelectSubps(i).weight,ObjVals,params.Dmethod);
    Allobjs=[subjs;objs'];
    SelectSubps(i).subpmin=min(Allobjs);
    SelectSubps(i).subpobjs=Allobjs;
    if ~strcmp(params.ModelMethod,'TrGP')
        if params.TrainSize>=Npoints
            SelectIdxes=1:Npoints;
        else    
            N_SelectIdxes=params.TrainSize;
            N_SelectIdxes_greedy=ceil(0.9*params.TrainSize);
            [~,Idxes]=sort(Allobjs,1);    
            SelectIdxes_greedy=Idxes(1:N_SelectIdxes_greedy)';
            RemainIdxes=setdiff(1:Npoints,SelectIdxes_greedy);
            SelectIdxes=[SelectIdxes_greedy,RemainIdxes(randperm(length(RemainIdxes),N_SelectIdxes-length(SelectIdxes_greedy)))];            
        end
        Xtrain{1,i}=InitialX(:,SelectIdxes).';
        Ytrain{1,i}=Allobjs(SelectIdxes);
    end
end
end