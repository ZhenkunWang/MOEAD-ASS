function [m,s2] = predict_tasks(S_test,MTGP_model,subproblems)
N_task=MTGP_model.N_task; N_model=MTGP_model.N_model; n_test=size(S_test,1);
sX=MTGP_model.sX; sY=MTGP_model.sY;
X_train=MTGP_model.x_train; Y_train=MTGP_model.y_train;
ModelMethod = MTGP_model.method;
if strcmp(ModelMethod,'InGP')||strcmp(ModelMethod,'TrGP')
    if strcmp(func2str(MTGP_model.GPfunc),'gp')
        X_test=cellfun(@(x,y) (S_test-x)./y,sX(1,:),sX(2,:),'UniformOutput',false);
    else
        X_test=arrayfun(@(x,y,z) [((S_test-x{:})./y{:}),z*ones(n_test,1)],sX(1,:),sX(2,:),1:N_model,'UniformOutput',false);
    end
else
    X_test_tem=cellfun(@(x,y,z) [(S_test-x)./y,z*ones(n_test,1)],sX(1,:),sX(2,:),num2cell(1:N_task),'UniformOutput',false);
    X_test={cell2mat(X_test_tem')};
end

if strcmp(ModelMethod,'InGP')||strcmp(ModelMethod,'TrGP')
    m=cell(1,N_model);s2=m;
for i=1:N_model
    [mu_t,s2_t]=feval(MTGP_model.GPfunc,MTGP_model.hyps(i),MTGP_model.inffunc,MTGP_model.meanfunc,MTGP_model.covfunc,MTGP_model.likfunc,X_train{i},MTGP_model.posts(i),X_test{i});
    m{i}=mu_t*sY{2,i}+sY{1,i};
    s2{i}=s2_t*(sY{2,i}^2);
end
else
    [mu_t,s2_t]=feval(MTGP_model.GPfunc,MTGP_model.hyps,MTGP_model.inffunc,MTGP_model.meanfunc,MTGP_model.covfunc,MTGP_model.likfunc,X_train{:},MTGP_model.posts,X_test{:});
    m_temp=mat2cell(mu_t,n_test*ones(N_task,1),1)';
    s2_temp=mat2cell(s2_t,n_test*ones(N_task,1),1)';
    m=cellfun(@(x,y,z) x*y+z,m_temp,sY(2,:),sY(1,:),'UniformOutput',false);
    s2=cellfun(@(x,y) x*(y^2),s2_temp,sY(2,:),'UniformOutput',false);
end
if strcmp(ModelMethod,'TrGP')
[m,s2]=transModelPred([subproblems.weight],m,s2,'tch');
end
end