function [m,s2]=transModelPred(weights,ObjMeans,ObjVars,method)
global idealpoint;
Objm=cell2mat(ObjMeans).'; Objs2=cell2mat(ObjVars).';
N_task=size(weights,2);
m=cell(1,N_task);s2=m;
if strcmp(method, 'ws')
    for i = 1: N_task
    [SubpMeans,SubpVars]=wsGP(weights(:,i),Objm,Objs2);
    m{i}=SubpMeans'; s2{i}=SubpVars';
    end
elseif strcmp(method, 'tch')
    for i = 1: N_task
    [SubpMeans,SubpVars]=tchGP(weights(:,i),Objm,Objs2,idealpoint(:,2));
    m{i}=SubpMeans'; s2{i}=SubpVars';
    end
else
    error('The selected mothod for GP model transfer is not supported');
end
end
% weighted sum scalarization Function
function [SubpMeans,SubpVars]=wsGP(weight,ObjMeans,ObjVars)
    s = size(weight, 2);
    indsize = size(ObjMeans,2);
    if s==1
    	SubpMeans=(weight'*ObjMeans);
        SubpVars=((weight.^2)'*ObjVars);
    elseif indsize==1 
     	SubpMeans=(weight'*ObjMeans)';
        SubpVars=((weight.^2)'*ObjVars)';       
    elseif indsize==s
        SubpMeans=sum(weight.*ObjMeans);
        SubpVars=sum((weight.^2).*ObjVars);
    else
        error('individual size must be same as weight size, or equals 1');
    end
end
% Techbycheff Scalarization Function
function [SubpMeans,SubpVars]=tchGP(weight,ObjMeans,ObjVars,idealpoint)
    [Nobj,Nw]= size(weight);
    Nind = size(ObjMeans,2);
    if Nind==1
       U=weight.*repmat((ObjMeans-idealpoint),1,Nw);
       V=(weight.^2).*repmat(ObjVars,1,Nw);
    elseif Nw==1
       U=repmat(weight,1,Nind).*(ObjMeans-repmat(idealpoint,1,Nind));
       V=(repmat(weight,1,Nind).^2).*ObjVars;
    elseif Nw==Nind
       U=weight.*(ObjMeans-repmat(idealpoint,1,Nind));
       V=(weight.^2).*ObjVars;
    else
        error('individual size must be same as weight size, or equals 1');
    end
    Cur_u=U(1,:);Cur_v=V(1,:);
    for i=2:Nobj
       u1=Cur_u;  v1=Cur_v;
       u2=U(i,:); v2=V(i,:);
       t=sqrt(v1+v2);
       a=(u1-u2)./t;
       Cur_u=u1.*normcdf(a)+u2.*normcdf(-a)+t.*normpdf(a);
       Cur_v=(u1.^2+v1).*normcdf(a)+(u2.^2+v2).*normcdf(-a)+(u1+u2).*t.*normpdf(a)-Cur_u.^2;
       if any(Cur_v<0)
           if all(Cur_v>-eps)
           Cur_v(Cur_v<0)=0;
           warning('Predicted objective variance is less than 0, and has been corrected to 0');
           else
           error('Predicted objective variance is less than 0, and the error is too large');
           end
       end       
    end
    SubpMeans=Cur_u; SubpVars=Cur_v;
end